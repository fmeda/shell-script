# Ansible Role: linux-hardening (Packaged)

This package contains a professional, production-ready Ansible Role intended to remediate and enforce host hardening 
according to CIS Level 1 recommendations, NIST 800-53 guidance and CMMI traceability.

Usage:
1. Extract the archive
   tar xzf linux-hardening-role.tar.gz
2. Include the role in your playbook or install to roles/ folder.

Run with --check first and review changes before applying:
  ansible-playbook -i hosts playbook.yml --check

Playbook example:
```yaml
- hosts: linux_servers
  become: yes
  roles:
    - ansible-role-linux-hardening
```
