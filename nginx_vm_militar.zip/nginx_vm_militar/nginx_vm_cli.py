#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import subprocess
import os
import argparse
from typing import List

class Colors:
    GREEN = "\033[92m"
    RED = "\033[91m"
    BLUE = "\033[94m"
    RESET = "\033[0m"

SYSTEM_DEPS: List[str] = ["qm", "vault", "nginx", "certbot", "ufw", "bash"]
PYTHON_DEPS: List[str] = ["colorama"]

def install_python_package(pkg: str) -> None:
    print(f"{Colors.BLUE}INFO{Colors.RESET} Instalando pacote Python: {pkg}...")
    subprocess.run([sys.executable, "-m", "pip", "install", "--user", pkg], check=True)
    print(f"{Colors.GREEN}OK{Colors.RESET} Pacote {pkg} instalado.")

def check_python_deps() -> None:
    try:
        import colorama
        from colorama import init
    except ImportError:
        install_python_package("colorama")
        from colorama import init
    init(autoreset=True)

def check_system_deps() -> None:
    missing: List[str] = []
    for dep in SYSTEM_DEPS:
        if subprocess.run(["which", dep], capture_output=True).returncode != 0:
            missing.append(dep)
    if missing:
        print(f"{Colors.RED}ERRO{Colors.RESET} Dependências faltando: {', '.join(missing)}")
        sys.exit(1)
    print(f"{Colors.GREEN}OK{Colors.RESET} Todas as dependências do sistema estão presentes.")

def run_script(script_path: str) -> None:
    if not os.path.isfile(script_path):
        print(f"{Colors.RED}ERRO{Colors.RESET} Script não encontrado: {script_path}")
        sys.exit(1)
    print(f"{Colors.BLUE}INFO{Colors.RESET} Executando {script_path}...")
    try:
        subprocess.run(["bash", script_path], check=True)
        print(f"{Colors.GREEN}OK{Colors.RESET} Script {script_path} executado com sucesso.")
    except subprocess.CalledProcessError:
        print(f"{Colors.RED}ERRO{Colors.RESET} Falha na execução do script {script_path}.")
        sys.exit(1)

def create_vm() -> None:
    print(f"{Colors.BLUE}=== Criando VM ==={Colors.RESET}")
    run_script("scripts/create_vm.sh")

def install_nginx() -> None:
    print(f"{Colors.BLUE}=== Instalando Nginx ==={Colors.RESET}")
    run_script("scripts/install_nginx.sh")

def hardening_nginx() -> None:
    print(f"{Colors.BLUE}=== Aplicando Hardening Nginx ==={Colors.RESET}")
    run_script("scripts/hardening_nginx.sh")

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Automação Militar: VM + Nginx + Hardening CMNI",
        epilog="Exemplo: python3 nginx_vm_cli.py --all"
    )
    parser.add_argument("--create-vm", action="store_true", help="Cria a VM segura")
    parser.add_argument("--install-nginx", action="store_true", help="Instala Nginx")
    parser.add_argument("--hardening", action="store_true", help="Aplica hardening")
    parser.add_argument("--all", action="store_true", help="Executa todas etapas")
    args = parser.parse_args()

    print(f"{Colors.BLUE}INFO{Colors.RESET} Verificando dependências Python...")
    check_python_deps()
    print(f"{Colors.BLUE}INFO{Colors.RESET} Verificando dependências do sistema...")
    check_system_deps()

    if args.all:
        create_vm()
        install_nginx()
        hardening_nginx()
    else:
        if args.create_vm:
            create_vm()
        if args.install_nginx:
            install_nginx()
        if args.hardening:
            hardening_nginx()

    print(f"{Colors.GREEN}SUCCESS{Colors.RESET} Operação concluída com sucesso!")

if __name__ == "__main__":
    main()
