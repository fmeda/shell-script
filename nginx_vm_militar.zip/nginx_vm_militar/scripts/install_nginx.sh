#!/bin/bash
set -euo pipefail

echo "INFO Atualizando pacotes..."
sudo apt update && sudo apt upgrade -y

echo "INFO Instalando Nginx e Certbot..."
sudo apt install -y nginx certbot python3-certbot-nginx ufw

sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 'Nginx Full'
sudo ufw --force enable

CERT_DOMAIN=$(vault kv get -field=domain secret/nginx_vm)
ADMIN_EMAIL=$(vault kv get -field=email secret/nginx_vm)
sudo certbot --nginx -d $CERT_DOMAIN --non-interactive --agree-tos -m $ADMIN_EMAIL

sudo nginx -t
sudo systemctl restart nginx
echo "OK Nginx instalado e seguro."
