#!/bin/bash
set -euo pipefail

NGINX_CONF="/etc/nginx/nginx.conf"

echo "INFO Aplicando hardening..."
sudo tee -a $NGINX_CONF > /dev/null <<EOL
server_tokens off;
ssl_protocols TLSv1.3;
ssl_prefer_server_ciphers on;
ssl_ciphers "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256";
add_header X-Frame-Options "SAMEORIGIN";
add_header X-Content-Type-Options "nosniff";
add_header Referrer-Policy "strict-origin";
add_header Permissions-Policy "geolocation=(), microphone=(), camera=()";
EOL

sudo nginx -t
sudo systemctl reload nginx
echo "OK Hardening aplicado."
