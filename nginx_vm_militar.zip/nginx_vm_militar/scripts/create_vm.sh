#!/bin/bash
set -euo pipefail

VM_NAME="nginx-server"
CPU="2"
RAM="2048"
DISK="20G"
IMAGE="ubuntu-24.04-cloudimg.qcow2"

CIPASSWORD=$(vault kv get -field=password secret/nginx_vm)

echo "INFO Criando VM: $VM_NAME ..."
qm create 9000 --name $VM_NAME --memory $RAM --cores $CPU --net0 virtio,bridge=vmbr0
qm importdisk 9000 $IMAGE local-lvm
qm set 9000 --scsihw virtio-scsi-pci --scsi0 local-lvm:vm-9000-disk-0
qm set 9000 --ide2 local-lvm:cloudinit
qm set 9000 --boot c --bootdisk scsi0
qm set 9000 --serial0 socket --vga serial0
qm set 9000 --ciuser devops --cipassword "$CIPASSWORD"
qm set 9000 --ipconfig0 ip=dhcp
qm start 9000
echo "OK VM $VM_NAME criada com sucesso."
