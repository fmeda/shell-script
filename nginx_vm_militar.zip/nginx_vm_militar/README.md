# Projeto Militar Nível CMNI 2025/2026
Automação completa: VM + Nginx + Hardening

## Funcionalidades
- Criação de VM segura via Cloud-init / Proxmox
- Instalação automática do Nginx com SSL Let's Encrypt
- Hardening completo Nginx (TLS 1.3, headers de segurança, CIS)
- Firewall Zero Trust (UFW)
- Pré-check de dependências Python e Sistema
- CLI intuitivo com mensagens amigáveis
- Preparado para auditoria e CI/CD
- Variáveis sensíveis via Vault ou .env

## Uso do CLI
python3 nginx_vm_cli.py --help
python3 nginx_vm_cli.py --create-vm
python3 nginx_vm_cli.py --install-nginx
python3 nginx_vm_cli.py --hardening
python3 nginx_vm_cli.py --all
