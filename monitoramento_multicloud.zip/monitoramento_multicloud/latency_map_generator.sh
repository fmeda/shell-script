#!/bin/bash
set -euo pipefail
umask 077

OUTPUT="/tmp/latency_map_$(date +%Y%m%d_%H%M%S).csv"
HOSTS=("8.8.8.8" "1.1.1.1" "cloudflare.com" "google.com")

echo "source,target,latency_ms" > "$OUTPUT"

for src in "${HOSTS[@]}"; do
  for dst in "${HOSTS[@]}"; do
    if [[ "$src" != "$dst" ]]; then
      latency=$(ping -c 3 -q "$dst" | awk -F '/' '/rtt/ {print $5}')
      latency=${latency:-"N/A"}
      echo "$src,$dst,$latency" >> "$OUTPUT"
    fi
  done
done

echo "Mapa de latência gerado em: $OUTPUT"
