#!/bin/bash
set -euo pipefail
umask 077

# Requer: aws-cli, az-cli, gcloud-cli, curl, ping, ssh, jq

LOG_FILE="/var/log/cloud_instance_health_check.log"
TMP_FILE="/tmp/cloud_instances.json"

log() {
  echo "$(date '+%F %T') [INFO] $1" | tee -a "$LOG_FILE"
}

check_connectivity() {
  local ip="$1"
  local result="CRITICAL"
  if ping -c 1 -W 2 "$ip" &> /dev/null; then
    result="OK"
  fi
  echo "$result"
}

check_http() {
  local ip="$1"
  if curl -s --connect-timeout 2 "http://$ip" &> /dev/null; then
    echo "OK"
  else
    echo "CRITICAL"
  fi
}

check_uptime() {
  local ip="$1"
  ssh -o ConnectTimeout=2 -o BatchMode=yes "$ip" uptime 2>/dev/null || echo "N/A"
}

output_json() {
  jq -n --arg provider "$1" --arg instance_id "$2" --arg ip "$3" \
        --arg ping "$4" --arg http "$5" --arg uptime "$6" --arg status "$7" \
    '{provider: $provider, instance_id: $instance_id, ip: $ip, ping: $ping, http_status: $http, uptime: $uptime, status: $status}'
}

main() {
  log "Iniciando verificação de instâncias nas clouds"

  for provider in AWS AZURE GCP; do
    log "Checando provedor: $provider"
    case "$provider" in
      AWS)
        for id in $(aws ec2 describe-instances --query 'Reservations[].Instances[].InstanceId' --output text); do
          ip=$(aws ec2 describe-instances --instance-ids "$id" --query 'Reservations[].Instances[].PublicIpAddress' --output text)
          ping=$(check_connectivity "$ip")
          http=$(check_http "$ip")
          uptime=$(check_uptime "$ip")
          status="OK"
          [[ $ping == "CRITICAL" || $http == "CRITICAL" ]] && status="CRITICAL"
          output_json "$provider" "$id" "$ip" "$ping" "$http" "$uptime" "$status"
        done
        ;;
      AZURE)
        az vm list-ip-addresses --output json > "$TMP_FILE"
        for ip in $(jq -r '.[].virtualMachine.network.publicIpAddresses[].ipAddress' "$TMP_FILE"); do
          ping=$(check_connectivity "$ip")
          http=$(check_http "$ip")
          uptime=$(check_uptime "$ip")
          status="OK"
          [[ $ping == "CRITICAL" || $http == "CRITICAL" ]] && status="CRITICAL"
          output_json "$provider" "$ip" "$ip" "$ping" "$http" "$uptime" "$status"
        done
        ;;
      GCP)
        gcloud compute instances list --format=json > "$TMP_FILE"
        for row in $(jq -c '.[]' "$TMP_FILE"); do
          ip=$(echo "$row" | jq -r '.networkInterfaces[0].accessConfigs[0].natIP')
          id=$(echo "$row" | jq -r '.name')
          ping=$(check_connectivity "$ip")
          http=$(check_http "$ip")
          uptime=$(check_uptime "$ip")
          status="OK"
          [[ $ping == "CRITICAL" || $http == "CRITICAL" ]] && status="CRITICAL"
          output_json "$provider" "$id" "$ip" "$ping" "$http" "$uptime" "$status"
        done
        ;;
    esac
  done

  log "Verificação concluída"
}

main
