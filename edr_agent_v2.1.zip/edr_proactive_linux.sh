#!/bin/bash

# ============================================
# EDR + SOC Proativo para Linux - Versão 2.1
# ============================================

# ----------- CONFIGURAÇÕES INICIAIS -----------
SCRIPT_NAME="$(basename "$0")"
EXPECTED_HASH="<INSERIR_HASH_REAL_DO_SCRIPT>"
TMP_LOG="/opt/edr/logs/edr_proactive.log"
IOC_LIST="/opt/edr/config/iocs.txt"
GPG_SECRET="${GPG_SECRET}" # exportar externamente via ambiente seguro
HOSTNAME=$(hostname)

# ----------- CARGA SEGURA DE CREDENCIAIS -----------
load_credentials() {
    gpg --quiet --batch --yes --decrypt --passphrase="$GPG_SECRET" \
        ~/.config/edr.env.gpg | while read line; do export "$line"; done
    export SIEM_URL
    export ZBX_SERVER
}

# ----------- VERIFICAÇÃO DE INTEGRIDADE -----------
verify_integrity() {
    CURR_HASH=$(sha256sum "$0" | awk '{print $1}')
    if [ "$EXPECTED_HASH" != "$CURR_HASH" ]; then
        echo "[ALERTA] O script foi modificado! Abortando."
        exit 1
    fi
}

# ----------- LOG SEGURO + HASH -----------
secure_log_event() {
    MSG="$1"
    TS="$(date '+%Y-%m-%d %H:%M:%S')"
    ENTRY="$TS | $HOSTNAME | $MSG"
    HASH=$(echo "$ENTRY" | sha256sum | awk '{print $1}')
    echo "$ENTRY | hash:$HASH" >> "$TMP_LOG"
    logger -p authpriv.notice "$ENTRY"
    curl --tlsv1.3 --cacert /etc/ssl/certs/ca-certificates.crt -s -H "Content-Type: application/json" \
        -d "{\"host\":\"$HOSTNAME\",\"event\":\"$MSG\"}" "$SIEM_URL" >/dev/null 2>&1
    zabbix_sender -z "$ZBX_SERVER" -s "$HOSTNAME" -k edr.event -o "$MSG" >/dev/null 2>&1
}

# ----------- IOC DETECTION -----------
check_iocs() {
    [[ ! -f "$IOC_LIST" ]] && return
    while read -r ioc; do
        netstat -anp | grep "$ioc" && secure_log_event "[ALERTA] Conexao com IOC: $ioc"
        ps aux | grep "$ioc" | grep -v grep && secure_log_event "[ALERTA] Processo IOC ativo: $ioc"
    done < "$IOC_LIST"
}

# ----------- MONITORAMENTO DE PROCESSOS -----------
check_processes() {
    patterns=("nc -e" "bash -i" "sh -i" "/dev/tcp" "curl http" "wget http")
    for pid in $(ps -eo pid --no-headers); do
        CMD=$(tr '\0' ' ' < /proc/$pid/cmdline 2>/dev/null)
        for pattern in "${patterns[@]}"; do
            echo "$CMD" | grep -q "$pattern" && {
                secure_log_event "[!] Processo suspeito PID:$pid CMD:$CMD"
                kill -9 "$pid" && secure_log_event "[AUTOMAÇÃO] Processo $pid encerrado automaticamente."
            }
        done
    done
}

# ----------- AUDITORIA DE COMANDOS SENSÍVEIS -----------
setup_audit_rules() {
    auditctl -w /bin/bash -p x -k shell_exec
    auditctl -w /usr/bin/curl -p x -k curl_exec
    auditctl -w /usr/bin/wget -p x -k wget_exec
}

check_auditd_events() {
    ausearch -k shell_exec -ts recent | grep 'execve' | while read -r line; do
        secure_log_event "[AUDIT] Execução detectada: $line"
    done
}

# ----------- MONITORAMENTO DE ARQUIVOS -----------
watch_critical_files() {
    inotifywait -m -e modify,create,delete /etc /var/spool/cron /root/.bashrc |
    while read path action file; do
        secure_log_event "[!] ALTERACAO CRITICA: $action em $path$file"
    done
}

# ----------- HARDENING DE KERNEL E SO -----------
kernel_hardening() {
    sysctl -w kernel.kptr_restrict=2
    sysctl -w kernel.dmesg_restrict=1
    sysctl -w fs.protected_hardlinks=1
    sysctl -w fs.protected_symlinks=1
}

# ----------- LOOP PRINCIPAL -----------
main_loop() {
    echo "[*] Iniciando monitoramento EDR proativo..."
    while true; do
        check_processes
        check_iocs
        check_auditd_events
        sleep 30
    done
}

# ----------- EXECUÇÃO SEGURO -----------
load_credentials
verify_integrity
kernel_hardening
setup_audit_rules
watch_critical_files &
main_loop
