#!/bin/bash
gpg --verify edr_proactive_linux.sh.asc edr_proactive_linux.sh