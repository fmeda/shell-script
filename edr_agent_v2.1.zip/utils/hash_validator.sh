#!/bin/bash
EXPECTED_HASH="(defina o hash aqui)"
CURRENT_HASH=$(sha256sum /opt/edr/edr_proactive_linux.sh | awk '{print $1}')
if [ "$CURRENT_HASH" == "$EXPECTED_HASH" ]; then
  echo "Integridade OK"
else
  echo "FALHA DE INTEGRIDADE"
fi