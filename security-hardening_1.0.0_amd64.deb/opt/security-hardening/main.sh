#!/bin/bash
echo "Security Hardening Platform - installed via DEB"
