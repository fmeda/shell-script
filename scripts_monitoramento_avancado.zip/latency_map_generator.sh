#!/bin/bash
set -e
set -o pipefail
IFS=$'\n'

declare -a HOSTS=("192.168.1.1" "google.com" "8.8.8.8" "cloudflare.com")
OUTPUT_CSV="/tmp/latency_map_$(date +%F_%H%M%S).csv"

log() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $1"
}

log "Iniciando geração de mapa de latência..."

echo "source,target,latency_ms" > "$OUTPUT_CSV"

for src in "${HOSTS[@]}"; do
    for tgt in "${HOSTS[@]}"; do
        if [[ "$src" != "$tgt" ]]; then
            latency=$(fping -c3 -q "$tgt" 2>&1 | awk -F'/' '/avg/ {print $8}' | sed 's/ms//')
            latency=${latency:-9999}
            echo "$src,$tgt,$latency" >> "$OUTPUT_CSV"
        fi
    done
done

log "Arquivo CSV gerado: $OUTPUT_CSV"
