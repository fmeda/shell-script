#!/usr/bin/env python3

import argparse
import logging
from logging.handlers import RotatingFileHandler
from dataclasses import dataclass
from typing import Optional
from datetime import datetime
import json

# =============================
# MODELS
# =============================

@dataclass
class ACLRule:
    action: str
    protocol: str
    src: str
    src_wildcard: str
    dst: str
    dst_wildcard: str
    port: Optional[int] = None

    def generate(self) -> str:
        base = f"{self.action} {self.protocol} {self.src} {self.src_wildcard} {self.dst} {self.dst_wildcard}"
        if self.port and self.protocol in ["tcp", "udp"]:
            return f"{base} eq {self.port}"
        return base


class CiscoACLBuilder:

    def __init__(self, name: str):
        self.name = name
        self.rules = []

    def add_rule(self, rule: ACLRule):
        logging.debug("Adding rule to ACL")
        self.rules.append(rule)

    def build(self) -> str:
        logging.info(f"Building ACL: {self.name}")

        config = []
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        config.append(f"! Generated on {timestamp}")
        config.append(f"ip access-list extended {self.name}")

        for rule in self.rules:
            config.append(f" {rule.generate()}")

        config.append("!")
        return "\n".join(config)

    def export_to_file(self, filename: str):
        logging.info(f"Exporting ACL to file: {filename}")
        with open(filename, "w") as f:
            f.write(self.build())


# =============================
# LOGGING SETUP
# =============================

def setup_logging(log_file: str, level: str):

    numeric_level = getattr(logging, level.upper(), logging.INFO)

    handler = RotatingFileHandler(
        log_file,
        maxBytes=2 * 1024 * 1024,
        backupCount=3
    )

    logging.basicConfig(
        level=numeric_level,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[handler]
    )

    logging.info("Logging initialized")


# =============================
# CLI
# =============================

def main():

    parser = argparse.ArgumentParser(
        prog="acl-governance",
        description="Enterprise Cisco ACL Governance Framework with Logging"
    )

    subparsers = parser.add_subparsers(dest="command")

    create_parser = subparsers.add_parser("create", help="Create a new ACL rule")

    create_parser.add_argument("--name", required=True, help="ACL name")
    create_parser.add_argument("--action", choices=["permit", "deny"], required=True)
    create_parser.add_argument("--protocol", choices=["ip", "tcp", "udp", "icmp"], required=True)
    create_parser.add_argument("--src", required=True)
    create_parser.add_argument("--src-wildcard", default="0.0.0.0")
    create_parser.add_argument("--dst", required=True)
    create_parser.add_argument("--dst-wildcard", default="0.0.0.0")
    create_parser.add_argument("--port", type=int)
    create_parser.add_argument("--output")
    create_parser.add_argument("--log-file", default="acl_governance.log")
    create_parser.add_argument("--log-level", default="INFO")

    args = parser.parse_args()

    if args.command == "create":

        setup_logging(args.log_file, args.log_level)

        try:
            logging.info("Starting ACL creation process")

            acl = CiscoACLBuilder(name=args.name)

            rule = ACLRule(
                action=args.action,
                protocol=args.protocol,
                src=args.src,
                src_wildcard=args.src_wildcard,
                dst=args.dst,
                dst_wildcard=args.dst_wildcard,
                port=args.port
            )

            acl.add_rule(rule)

            config = acl.build()
            print(config)

            if args.output:
                acl.export_to_file(args.output)

            logging.info(json.dumps({
                "event": "acl_create",
                "acl_name": args.name,
                "status": "success"
            }))

        except Exception as e:
            logging.error(f"Error during ACL creation: {e}")
            print(f"Error: {e}")


if __name__ == "__main__":
    main()
