# Conteúdo do script wazuh_setup.sh
