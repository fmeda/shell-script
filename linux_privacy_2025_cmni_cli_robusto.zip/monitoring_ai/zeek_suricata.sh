# Conteúdo do script zeek_suricata.sh
