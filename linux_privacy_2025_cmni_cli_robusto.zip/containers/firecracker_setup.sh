# Conteúdo do script firecracker_setup.sh
