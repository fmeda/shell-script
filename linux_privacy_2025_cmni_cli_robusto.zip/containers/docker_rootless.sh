# Conteúdo do script docker_rootless.sh
