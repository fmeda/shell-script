# Conteúdo do script hardware_key_setup.sh
