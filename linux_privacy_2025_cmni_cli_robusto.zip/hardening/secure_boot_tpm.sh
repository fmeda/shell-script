# Conteúdo do script secure_boot_tpm.sh
