# Conteúdo do script firefox_hardened.sh
