# Conteúdo do script dnscrypt_setup.sh
