# Conteúdo do arquivo pre_check_install.sh
