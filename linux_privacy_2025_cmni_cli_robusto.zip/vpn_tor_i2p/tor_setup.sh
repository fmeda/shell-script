# Conteúdo do script tor_setup.sh
