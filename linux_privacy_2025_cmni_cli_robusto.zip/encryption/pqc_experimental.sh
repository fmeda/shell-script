# Conteúdo do script pqc_experimental.sh
