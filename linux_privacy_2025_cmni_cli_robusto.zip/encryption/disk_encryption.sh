# Conteúdo do script disk_encryption.sh
