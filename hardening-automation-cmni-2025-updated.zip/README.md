# Unified Hardening Automation (CMNI-HARDENED)

Repositório com playbooks, roles e scripts para hardening, observabilidade e mitigação em ambientes Linux (VMs, containerd/CRI-O, Kubernetes 2025-ready).

Use `./bootstrap.sh --help` para instruções.
