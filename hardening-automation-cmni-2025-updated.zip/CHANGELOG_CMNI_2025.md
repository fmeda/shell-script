    CHANGELOG - CMNI HARDENED - 2025

- 2025-08: Atualizado para práticas 2025: containerd/CRI-O preferência, Cilium/eBPF placeholders, cosign integration, Kubernetes 1.31 compatible manifests.
- Added: bootstrap.sh --verify, sigverify role, forensics playbook, containerd config template.
