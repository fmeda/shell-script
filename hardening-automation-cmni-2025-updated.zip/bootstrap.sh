#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
INVENTORY="$ROOT_DIR/inventory/hosts.ini"
ANSIBLE_PLAYBOOK="$ROOT_DIR/ansible/playbooks/site.yml"
CHECKSUMS_FILE="$ROOT_DIR/.checksums.sha256"
GPG_KEY_ID_FILE="$ROOT_DIR/.gpg_key_id"
ANSIBLE_ARGS=${ANSIBLE_ARGS:-}

usage(){
  cat <<EOF
Usage: $0 [run|verify|lint|help] [--ansible-args "..."]
  run       : run the playbook (default)
  verify    : verify checksums and GPG signatures
  lint      : lint YAML
  help      : show this help
EOF
}

check_deps(){
  echo "[+] Verificando dependências..."
  local deps=(python3 ansible-playbook ssh scp git sha256sum gpg cosign kubectl)
  for d in "${deps[@]}"; do
    if ! command -v "$d" &>/dev/null; then
      echo "ERRO: depende de '$d' - instale antes." >&2
      exit 1
    fi
  done
}

verify_artifacts(){
  echo "[+] Verificando checksums SHA256..."
  if [[ -f "$CHECKSUMS_FILE" ]]; then
    sha256sum -c "$CHECKSUMS_FILE" || { echo "Checksums inválidos"; exit 2; }
  else
    echo "Aviso: $CHECKSUMS_FILE não encontrado. Pulei verificação." >&2
  fi
  if [[ -f "$GPG_KEY_ID_FILE" ]]; then
    KEYID=$(cat "$GPG_KEY_ID_FILE")
    echo "[+] Verificando assinaturas GPG com KEYID=$KEYID (se existirem .sig)..."
    for f in $(find . -type f -name "*.sig" -printf '%P\n' | sed 's/\.sig$//'); do
      if ! gpg --keyring "$ROOT_DIR/.trustedkeys.gpg" --verify "$f.sig" "$f" 2>/dev/null; then
        echo "FALHA: assinatura inválida para $f"; exit 3
      fi
    done
  fi
  echo "[+] Verificações concluídas."
}

run_playbook(){
  echo "[+] Executando Ansible playbook..."
  ansible-playbook -i "$INVENTORY" "$ANSIBLE_PLAYBOOK" ${ANSIBLE_ARGS}
}

case ${1:-run} in
  run)
    check_deps
    verify_artifacts || true
    run_playbook
    ;;
  verify)
    check_deps
    verify_artifacts
    ;;
  lint)
    yamllint -c .yamllint.yml . || true
    ;;
  help|-h|--help)
    usage
    ;;
  *)
    echo "Opção inválida: $1"; exit 2
    ;;
esac
